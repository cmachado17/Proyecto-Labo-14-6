#ifndef FUNCIONESGLOBALES_H_INCLUDED
#define FUNCIONESGLOBALES_H_INCLUDED
#include "ConsumoProducto.h"
#include "ConsumoPlatillo.h"
#include "OrientacionAlimentaria.h"
#include "Platillo.h"


void menuConsumos();
string mostrarOrientacionAlimentaria(int id);
string mostrarNombreProducto(int id);
string mostrarNombrePlatillo(int id);













#endif // FUNCIONESGLOBALES_H_INCLUDED
